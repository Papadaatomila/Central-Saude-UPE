import { keepPreviousData, useQuery } from '@tanstack/react-query'
import { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router'
import type { components } from '../../shared/api/generated/schema'
import { http } from '../../shared/api/http'
import { ApiError } from '../../shared/api/problem-details'
import { CampoSelecao } from '../../shared/ui/CampoSelecao'
import { Campo } from '../../shared/ui/Campo'
import { Botao } from '../../shared/ui/Botao'
import { Alerta } from '../../shared/ui/Alerta'
import { Cartao } from '../../shared/ui/Cartao'
import { SeloRisco } from './PedidosFila'
import { filasEquipeOptions } from './api'
import { hojeRecife, periodo, validarPeriodo, rotuloDia } from './periodo-indicadores'
import './indicadores.css'

type Saida = components['schemas']['IndicadoresSaida']
const inteiro = (n: number) => n.toLocaleString('pt-BR')
const decimal = (n: number | null) => n === null ? '—' : n.toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 })
const percentual = (n: number | null) => n === null ? '—' : `${decimal(n * 100)}%`
function CartaoNumero({ titulo, valor, ajuda }: { titulo: string; valor: string; ajuda: string }) {
  return <Cartao><h2>{titulo}</h2><p className="indicador-numero">{valor}</p><p>{ajuda}</p></Cartao>
}
export default function Indicadores() {
  const [params, setParams] = useSearchParams()
  const padrao = periodo('4')
  const de = params.get('de') ?? padrao.de
  const ate = params.get('ate') ?? padrao.ate
  const fila = params.get('fila') ?? ''
  const [modo, setModo] = useState(params.has('de') ? 'personalizado' : '4')
  const [inicio, setInicio] = useState(de)
  const [fim, setFim] = useState(ate)
  const [erroLocal, setErroLocal] = useState('')
  const chaveUrl = `${de}/${ate}/${fila}`
  const [urlAnterior, setUrlAnterior] = useState(chaveUrl)
  if (urlAnterior !== chaveUrl) {
    setUrlAnterior(chaveUrl)
    setInicio(de)
    setFim(ate)
    setErroLocal('')
    const preset = ['4', '8', 'mes'].find((tipo) => { const p = periodo(tipo); return p.de === de && p.ate === ate })
    setModo(preset ?? 'personalizado')
  }
  const [agora, setAgora] = useState(Date.now)
  const mesComUmDia = de === ate && de === hojeRecife() && de.endsWith('-01')
  const erroPeriodo = mesComUmDia ? '' : validarPeriodo(de, ate)
  const filaValida = !fila || /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(fila)
  const filas = useQuery({ ...filasEquipeOptions, refetchOnWindowFocus: false, refetchOnReconnect: false })
  const consulta = useQuery({
    queryKey: ['indicadores', de, ate, fila],
    queryFn: ({ signal }) => {
      const busca = new URLSearchParams({ de, ate })
      if (fila) busca.set('fila_id', fila)
      return http.request<Saida>(`/equipe/indicadores?${busca}`, { signal })
    },
    enabled: !erroPeriodo && filaValida,
    placeholderData: keepPreviousData,
    refetchOnWindowFocus: false, refetchOnReconnect: false, retry: false,
  })
  const falha = consulta.error instanceof ApiError ? consulta.error : undefined
  const retry = falha?.response.headers.get('Retry-After')
  const espera = retry ? (/^\d+$/.test(retry) ? consulta.errorUpdatedAt + Number(retry) * 1000 : Date.parse(retry)) : 0
  const bloqueado = Boolean(consulta.isError && espera > agora)
  useEffect(() => {
    if (!bloqueado) return
    const timer = setInterval(() => setAgora(Date.now()), 250)
    return () => clearInterval(timer)
  }, [bloqueado])
  function aplicar(a: string, b: string, f = fila, diaUnicoDoMes = false) {
    const erro = diaUnicoDoMes && a === b && a === hojeRecife() && a.endsWith('-01') ? '' : validarPeriodo(a, b)
    setErroLocal(erro)
    if (erro) return
    setParams({ de: a, ate: b, ...(f ? { fila: f } : {}) })
  }
  const dados = consulta.data
  const t = dados?.totais
  const semMovimento = t && ![t.solicitacoes_criadas, t.confirmadas, t.recusadas, t.expiradas, t.realizadas, t.faltas, t.vagas_ofertadas, t.desistencias].some(Boolean)
  const erroFiltro = erroLocal || erroPeriodo || (falha?.problem.status === 422 ? 'Confira o período informado (até 366 dias).' : '')
  return <section className="indicadores"><h1>Indicadores</h1><p>Acompanhe os movimentos das filas do seu escopo.</p>
    <div className="indicadores-filtros">
      <CampoSelecao rotulo="Período" value={modo} onChange={(e) => {
        setModo(e.target.value)
        if (e.target.value !== 'personalizado') { const p = periodo(e.target.value); setInicio(p.de); setFim(p.ate); aplicar(p.de, p.ate, fila, e.target.value === 'mes') }
      }}><option value="4">Últimas 4 semanas</option><option value="8">Últimas 8 semanas</option><option value="mes">Este mês</option><option value="personalizado">Personalizado</option></CampoSelecao>
      <CampoSelecao rotulo="Fila" value={fila} disabled={filas.isPending || filas.isError} onChange={(e) => aplicar(de, ate, e.target.value, mesComUmDia)}>
        <option value="">Todas as minhas filas</option>{filas.data?.map((f) => <option key={f.id} value={f.id}>{f.unidade_sigla} · {f.nome}</option>)}
      </CampoSelecao>
    </div>
    {modo === 'personalizado' && <form className="indicadores-filtros" onSubmit={(e) => { e.preventDefault(); aplicar(inicio, fim) }}>
      <Campo rotulo="De" type="date" value={inicio} max={hojeRecife()} onChange={(e) => setInicio(e.target.value)} erro={erroFiltro || undefined} />
      <Campo rotulo="Até" type="date" value={fim} max={hojeRecife()} onChange={(e) => setFim(e.target.value)} />
      <Botao type="submit">Aplicar</Botao>
    </form>}
    {erroFiltro && <Alerta>{erroFiltro}</Alerta>}{!filaValida && <Alerta>Confira a fila informada no endereço.</Alerta>}
    {filas.isError && <Alerta>Não foi possível carregar as filas. <Botao onClick={() => void filas.refetch()}>Carregar filas</Botao></Alerta>}
    {consulta.isPending && !erroPeriodo && filaValida && <p role="status">Carregando indicadores…</p>}
    {consulta.isError && <Alerta>{falha?.problem.status === 403 ? 'Indicadores indisponíveis para este acesso.' : falha?.problem.status === 404 ? 'Fila não encontrada ou indisponível para este acesso.' : falha?.message ?? 'Não foi possível carregar os indicadores.'}
      <Botao disabled={bloqueado} onClick={() => { setAgora(Date.now()); void consulta.refetch() }}>Tentar novamente</Botao>{bloqueado && <p>Aguarde o prazo para tentar novamente.</p>}
    </Alerta>}
    {dados && <div aria-busy={consulta.isFetching} className={consulta.isFetching ? 'indicadores-atualizando' : undefined}>
      <p role="status">{consulta.isFetching ? 'Atualizando indicadores…' : `Indicadores de ${rotuloDia(dados.de)} a ${rotuloDia(dados.ate)}, ${dados.fila_id ? filas.data?.find((f) => f.id === dados.fila_id)?.nome ?? 'fila selecionada' : 'todas as filas'}`}</p>
      {semMovimento && <p>Nenhum movimento neste período.</p>}
      <div className="indicadores-cartoes">
        <CartaoNumero titulo="Taxa de confirmação" valor={percentual(dados.totais.taxa_confirmacao)} ajuda={dados.totais.taxa_confirmacao === null ? 'sem dados no período' : 'Confirmadas ÷ propostas encerradas, pela data da proposta.'} />
        <CartaoNumero titulo="Taxa de faltas" valor={percentual(dados.totais.taxa_faltas)} ajuda={dados.totais.taxa_faltas === null ? 'sem dados no período' : 'Faltas ÷ atendimentos realizados e faltas, pela data da vaga.'} />
        <CartaoNumero titulo="Tempo de espera" valor={`${decimal(dados.tempo_de_espera.mediana_dias)} dias (mediana) · ${decimal(dados.tempo_de_espera.p90_dias)} dias (P90)`} ajuda={`${inteiro(dados.tempo_de_espera.confirmacoes)} confirmações usadas. Da entrada na fila à primeira confirmação no período.${dados.tempo_de_espera.mediana_dias === null ? ' sem dados no período' : ''}`} />
        <CartaoNumero titulo="Vagas reaproveitadas" valor={inteiro(dados.totais.vagas_reaproveitadas)} ajuda="Proposta desfeita e depois confirmada por outro pedido." />
        <CartaoNumero titulo="Vagas perdidas" valor={inteiro(dados.totais.vagas_perdidas)} ajuda="Vagas ofertadas já iniciadas sem agendamento confirmado, realizado ou com falta." />
        <CartaoNumero titulo="Pedidos criados" valor={inteiro(dados.totais.solicitacoes_criadas)} ajuda="Pedidos criados no período escolhido." />
        <CartaoNumero titulo="Desistências" valor={inteiro(dados.totais.desistencias)} ajuda="Desses pedidos, os cancelados pelo paciente com motivo." />
      </div>
      <h2>Fila agora</h2><p>Não depende do período escolhido.</p><ul className="indicadores-riscos">{(['VERMELHO', 'AMARELO', 'VERDE'] as const).map((r) => <li key={r}><SeloRisco valor={r} /> {inteiro(dados.fila_atual[r] ?? 0)}</li>)}</ul>
      <h2>Semana a semana</h2><p>Pedidos criados e consultas confirmadas. Confirmações agrupadas pela data da proposta.</p>
      <div className="indicadores-grafico" role="img" aria-label={`Pedidos criados e consultas confirmadas em ${dados.semanas.length} semanas. Valores disponíveis em Ver tabela.`}>
        {dados.semanas.map((s) => { const max = Math.max(1, ...dados.semanas.flatMap((x) => [x.solicitacoes_criadas, x.confirmadas])); return <div className="indicadores-semana" key={s.semana}><div className="indicadores-barras"><span title={`Pedidos: ${s.solicitacoes_criadas}`} style={{ height: `${s.solicitacoes_criadas / max * 100}%` }} /><span title={`Confirmadas: ${s.confirmadas}`} style={{ height: `${s.confirmadas / max * 100}%` }} /></div><span>{rotuloDia(s.semana)}</span></div> })}
      </div><p>Azul: pedidos criados · Verde: consultas confirmadas</p>
      <details><summary>Ver tabela</summary><div className="indicadores-tabela"><table><caption>Movimento semanal das filas</caption><thead><tr><th scope="col">Semana</th><th scope="col">Pedidos criados</th><th scope="col">Consultas confirmadas</th></tr></thead><tbody>{dados.semanas.map((s) => <tr key={s.semana}><th scope="row">{rotuloDia(s.semana)}</th><td>{inteiro(s.solicitacoes_criadas)}</td><td>{inteiro(s.confirmadas)}</td></tr>)}</tbody></table></div></details>
    </div>}
  </section>
}
