import { QueryClientProvider } from '@tanstack/react-query'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, useNavigate } from 'react-router'
import { afterAll, afterEach, beforeAll, beforeEach, expect, it } from 'vitest'
import { http as msw, HttpResponse } from 'msw'
import { setupServer } from 'msw/node'
import { axe } from 'vitest-axe'
import { criarQueryClient } from '../../app/query-client'
import { http } from '../../shared/api/http'
import Indicadores from './Indicadores'
const resumo = { confirmadas: 29, recusadas: 7, expiradas: 4, propostas_encerradas: 40, propostas_canceladas_sem_resposta: 0, taxa_confirmacao: .725, taxa_recusa: .175, taxa_expiracao: .1, realizadas: 10, faltas: 0, taxa_faltas: null, solicitacoes_criadas: 1000, desistencias: 3, taxa_desistencia: .003, vagas_ofertadas: 40, vagas_ocupadas: 29, vagas_reaproveitadas: 4, vagas_perdidas: 2 }
let chamadas: URL[] = []
const servidor = setupServer(
  msw.get('*/api/v1/equipe/filas', () => HttpResponse.json({ itens: [], total: 0 })),
  msw.get('*/api/v1/equipe/indicadores', ({ request }) => {
    const url = new URL(request.url); chamadas.push(url)
    return HttpResponse.json({ de: url.searchParams.get('de'), ate: url.searchParams.get('ate'), fila_id: null, unidade_id: null, totais: resumo, semanas: [{ ...resumo, semana: '2026-11-02' }], tempo_de_espera: { mediana_dias: 4.2, p90_dias: 8.9, confirmacoes: 29 }, fila_atual: { VERMELHO: 2, AMARELO: 3, VERDE: 4 } })
  }),
)
beforeAll(() => servidor.listen({ onUnhandledFrame: 'error' }))
afterAll(() => servidor.close())
beforeEach(() => { chamadas = []; http.iniciarSessao() })
afterEach(() => servidor.resetHandlers())
function Voltar() { const navegar = useNavigate(); return <button onClick={() => void navegar(-1)}>Voltar no histórico</button> }
function abrir() { return render(<QueryClientProvider client={criarQueryClient()}><MemoryRouter initialEntries={['/equipe/indicadores?de=2026-10-01&ate=2026-11-07']}><Indicadores /><Voltar /></MemoryRouter></QueryClientProvider>) }
it('formata cartões, nulos, riscos, gráfico e tabela sem violações axe', async () => {
  const { container } = abrir()
  await screen.findByText('72,5%')
  expect(screen.getAllByText('1.000')).toHaveLength(2)
  expect(screen.getByText('—')).toBeTruthy()
  expect(screen.getByText(/4,2 dias.*8,9 dias/)).toBeTruthy()
  for (const risco of ['Alto', 'Médio', 'Baixo']) expect(screen.getByText(risco)).toBeTruthy()
  expect(screen.getByRole('img')).toBeTruthy()
  await userEvent.click(screen.getByText('Ver tabela'))
  expect(screen.getByRole('table', { name: 'Movimento semanal das filas' })).toBeTruthy()
  expect((await axe(container)).violations).toEqual([])
  expect(chamadas).toHaveLength(1)
})
it('personalizado aguarda Aplicar e impede período inválido', async () => {
  abrir(); await screen.findByText('72,5%')
  const user = userEvent.setup()
  await user.clear(screen.getByLabelText('De'))
  await user.type(screen.getByLabelText('De'), '2026-10-03')
  expect(chamadas).toHaveLength(1)
  await user.click(screen.getByRole('button', { name: 'Aplicar' }))
  await waitFor(() => expect(chamadas).toHaveLength(2))
  expect(chamadas[1]!.searchParams.get('de')).toBe('2026-10-03')
  await user.clear(screen.getByLabelText('Até'))
  await user.type(screen.getByLabelText('Até'), '2026-10-01')
  await user.click(screen.getByRole('button', { name: 'Aplicar' }))
  expect(chamadas).toHaveLength(2)
})
it.each([403, 404, 422, 503])('mostra erro %s e respeita Retry-After', async (status) => {
  servidor.use(msw.get('*/api/v1/equipe/indicadores', () => HttpResponse.json({ status, type: status === 503 ? '/problemas/consulta-demorada' : 'about:blank' }, { status, headers: { 'Content-Type': 'application/problem+json', 'Retry-After': '30' } })))
  abrir()
  const botao = await screen.findByRole('button', { name: 'Tentar novamente' })
  expect(botao.hasAttribute('disabled')).toBe(true)
})


it('cada período predefinido gera uma consulta sem fila_id', async () => {
  abrir(); await screen.findByText('72,5%')
  const user = userEvent.setup()
  for (const [indice, tipo] of ['4', '8', 'mes'].entries()) {
    await user.selectOptions(screen.getByLabelText('Período'), tipo)
    await waitFor(() => expect(chamadas).toHaveLength(indice + 2))
    expect(chamadas.at(-1)!.searchParams.has('fila_id')).toBe(false)
  }
})
it('fila específica envia somente seu id e Todas remove o parâmetro', async () => {
  const id = '00000000-0000-4000-8000-000000000001'
  servidor.use(msw.get('*/api/v1/equipe/filas', () => HttpResponse.json({ total: 1, itens: [{ id, nome: 'Fila sintética', unidade_sigla: 'CISAM', especialidade: 'Exemplo', ativa: true, contagem_por_status: {} }] })))
  abrir(); await screen.findByRole('option', { name: 'CISAM · Fila sintética' }); await screen.findByText('72,5%')
  const user = userEvent.setup()
  await user.selectOptions(screen.getByLabelText('Fila'), id)
  await waitFor(() => expect(chamadas).toHaveLength(2))
  expect(chamadas[1]!.searchParams.get('fila_id')).toBe(id)
  await user.selectOptions(screen.getByLabelText('Fila'), '')
  await waitFor(() => expect(chamadas).toHaveLength(3))
  expect(chamadas[2]!.searchParams.has('fila_id')).toBe(false)
})

it('Voltar restaura as datas da URL e do formulário', async () => {
  abrir(); await screen.findByText('72,5%')
  const user = userEvent.setup()
  await user.clear(screen.getByLabelText('De'))
  await user.type(screen.getByLabelText('De'), '2026-10-04')
  await user.click(screen.getByRole('button', { name: 'Aplicar' }))
  await waitFor(() => expect(chamadas).toHaveLength(2))
  await user.click(screen.getByRole('button', { name: 'Voltar no histórico' }))
  await waitFor(() => expect(chamadas).toHaveLength(3))
  expect((screen.getByLabelText('De') as HTMLInputElement).value).toBe('2026-10-01')
  expect(chamadas[2]!.searchParams.get('de')).toBe('2026-10-01')
})
