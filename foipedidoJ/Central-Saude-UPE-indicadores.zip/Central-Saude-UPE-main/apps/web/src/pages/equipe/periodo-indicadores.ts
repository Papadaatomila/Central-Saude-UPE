export function hojeRecife(agora = new Date()) {
  const partes = new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Recife', year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(agora)
  const parte = (nome: string) => partes.find((p) => p.type === nome)!.value
  return `${parte('year')}-${parte('month')}-${parte('day')}`
}
export const rotuloDia = (dia: string) => `${dia.slice(8, 10)}/${dia.slice(5, 7)}`
export function periodo(tipo: string, hoje = hojeRecife()) {
  const fim = new Date(`${hoje}T12:00:00Z`)
  if (tipo === 'mes') return { de: `${hoje.slice(0, 7)}-01`, ate: hoje }
  fim.setUTCDate(fim.getUTCDate() - (tipo === '8' ? 55 : 27))
  return { de: fim.toISOString().slice(0, 10), ate: hoje }
}
export function validarPeriodo(de: string, ate: string, hoje = hojeRecife()) {
  const valida = (d: string) => /^\d{4}-\d{2}-\d{2}$/.test(d) && Number.isFinite(Date.parse(d)) && new Date(d).toISOString().slice(0, 10) === d
  if (!valida(de) || !valida(ate)) return 'Informe datas válidas.'
  if (de >= ate) return 'A data inicial deve ser anterior à final.'
  if (ate > hoje) return 'O período deve terminar até hoje.'
  if ((Date.parse(ate) - Date.parse(de)) / 86400000 >= 366) return 'Escolha um período de até 366 dias.'
  return ''
}
