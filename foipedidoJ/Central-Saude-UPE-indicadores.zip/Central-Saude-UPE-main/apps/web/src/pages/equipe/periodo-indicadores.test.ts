import { describe, expect, it } from 'vitest'
import { hojeRecife, periodo, validarPeriodo, rotuloDia } from './periodo-indicadores'
describe('Indicadores — datas civis em Recife', () => {
  it('usa o dia anterior durante a virada UTC', () => expect(hojeRecife(new Date('2026-11-01T02:59:59Z'))).toBe('2026-10-31'))
  it('calcula 28 e 56 dias inclusivos e o mês', () => {
    expect(periodo('4', '2026-11-01')).toEqual({ de: '2026-10-05', ate: '2026-11-01' })
    expect(periodo('8', '2026-11-01')).toEqual({ de: '2026-09-07', ate: '2026-11-01' })
    expect(periodo('mes', '2026-11-07')).toEqual({ de: '2026-11-01', ate: '2026-11-07' })
  })
  it('rejeita datas inexistentes, futuras, invertidas e mais de 366 dias', () => {
    for (const [de, ate] of [['2026-02-30', '2026-03-02'], ['2026-11-02', '2026-11-01'], ['2026-01-01', '2027-01-03']]) expect(validarPeriodo(de!, ate!, '2027-12-31')).not.toBe('')
    expect(validarPeriodo('2026-01-01', '2026-11-08', '2026-11-07')).not.toBe('')
    expect(validarPeriodo('2024-01-01', '2024-12-31', '2026-11-07')).toBe('')
    expect(rotuloDia('2026-11-02')).toBe('02/11')
  })
})
