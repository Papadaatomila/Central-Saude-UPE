"""Área do paciente: filas, solicitações (UC-002) e resposta à proposta (UC-004, UC-005).

ADR-007: nenhuma resposta daqui traz posição, tamanho da fila, nota, pontos, pesos,
classificação de risco nem `data_entrada_fila`. Toda consulta filtra pelo paciente da sessão
dentro da query; solicitação de outro paciente responde 404 (AM-001).
"""

import logging
from datetime import date, datetime
from typing import Annotated, Literal
from uuid import UUID
from zoneinfo import ZoneInfo

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import and_, func, select
from sqlalchemy.orm import Session

from app.api.deps import get_relogio, get_session, ip_do_cliente, paciente_da_sessao
from app.api.paginacao import Limit, Offset, Pagina
from app.api.problemas import CSRF, NAO_AUTENTICADO, SEM_PERMISSAO, erros
from app.api.tipos import (
    MotivoCancelamento,
    StatusSolicitacao,
    TipoCriterio,
    TipoEventoLinhaDoTempo,
    Turno,
)
from app.config import get_settings
from app.dominio.relogio import Relogio
from app.infra.agendamentos import (
    ATIVOS,
    travar_agendamento,
)
from app.infra.modelos import (
    Agenda,
    Agendamento,
    CriterioFila,
    Especialidade,
    Fila,
    HistoricoSolicitacao,
    Paciente,
    RespostaCriterio,
    Solicitacao,
    Unidade,
    Vaga,
)
from app.infra.transicoes import (
    ENCERRADAS,
    cancelar_do_paciente,
    confirmar_do_paciente,
    criar_solicitacao,
    motivo_de_inelegibilidade,
    recusar_do_paciente,
)

logger = logging.getLogger(__name__)

router = APIRouter(tags=["paciente"])

PacienteDep = Annotated[Paciente, Depends(paciente_da_sessao)]
SessionDep = Annotated[Session, Depends(get_session)]
RelogioDep = Annotated[Relogio, Depends(get_relogio)]


# Erros comuns: sessão (401), papel (403) e, nas escritas, CSRF (403).
PACIENTE_LEITURA = (NAO_AUTENTICADO, SEM_PERMISSAO, 422)
PACIENTE_ESCRITA = (*PACIENTE_LEITURA, CSRF)


# --- schemas ------------------------------------------------------------------------------


class UnidadeSaida(BaseModel):
    id: UUID
    sigla: str
    nome: str


class EspecialidadeSaida(BaseModel):
    id: UUID
    nome: str


class FilaSaida(BaseModel):
    id: UUID
    nome: str
    descricao_paciente: str
    unidade: UnidadeSaida
    especialidade: EspecialidadeSaida
    elegivel: bool
    motivo_inelegivel: str | None


class CriterioPacienteSaida(BaseModel):
    """Sem peso, fatores nem pontos: o paciente só vê a pergunta."""

    id: UUID
    codigo: str
    descricao: str
    tipo: TipoCriterio
    opcoes: list[str] | None


class FilaDetalheSaida(FilaSaida):
    criterios: list[CriterioPacienteSaida]


class RespostaEntrada(BaseModel):
    model_config = ConfigDict(extra="forbid")

    criterio_id: UUID
    valor: bool | int | float | Annotated[str, Field(max_length=200)]


class SolicitacaoEntrada(BaseModel):
    """AM-013: sem status, risco, nota nem pontos; o servidor calcula."""

    model_config = ConfigDict(
        extra="forbid", str_strip_whitespace=True, use_enum_values=True, validate_default=True
    )

    fila_id: UUID
    turno_preferido: Turno = Turno.QUALQUER
    origem_encaminhamento: str = Field(min_length=2, max_length=200)
    respostas: list[RespostaEntrada] = Field(default_factory=list, max_length=50)


class CancelamentoEntrada(BaseModel):
    """Sem texto livre: só o código (`MOTIVOS_CANCELAMENTO`), validado pelo domínio."""

    model_config = ConfigDict(extra="forbid", use_enum_values=True)

    motivo_codigo: MotivoCancelamento


class FilaResumo(BaseModel):
    id: UUID
    nome: str
    unidade: UnidadeSaida


class SolicitacaoResumo(BaseModel):
    id: UUID
    status: StatusSolicitacao
    fila: FilaResumo
    data_pedido: date
    criada_em: datetime


class EventoPaciente(BaseModel):
    """Só o dia, sem hora: a hora de ENTROU_NA_FILA revelaria `data_entrada_fila` (ADR-007)."""

    tipo: TipoEventoLinhaDoTempo
    data: date
    motivo: str | None


class RespostaPaciente(BaseModel):
    descricao: str
    valor: bool | int | float | str


class AgendamentoResumo(BaseModel):
    """Proposta (com `expira_em`) ou consulta confirmada. Horários no fuso de Recife."""

    id: UUID  # para confirmar ou recusar sem abrir o detalhe
    status: Literal["PROPOSTO", "CONFIRMADO"]
    inicio: datetime
    expira_em: datetime | None  # só na proposta
    unidade: UnidadeSaida
    profissional: str  # UC-004: o paciente vê o profissional


class AgendamentoPaciente(AgendamentoResumo):
    fim: datetime
    endereco: str | None


class SolicitacaoItem(SolicitacaoResumo):
    """Item de "Meus atendimentos": o resumo da solicitação e do agendamento ativo."""

    agendamento_ativo: AgendamentoResumo | None


class PaginaSolicitacoes(Pagina[SolicitacaoItem]):
    pass


class PaginaFilas(Pagina[FilaSaida]):
    pass


class SolicitacaoDetalhe(SolicitacaoResumo):
    turno_preferido: Turno
    origem_encaminhamento: str | None
    respostas: list[RespostaPaciente]
    linha_do_tempo: list[EventoPaciente]
    agendamento_ativo: AgendamentoPaciente | None


# --- apoio --------------------------------------------------------------------------------


def _hoje(relogio: Relogio) -> date:
    return relogio.agora().astimezone(ZoneInfo(get_settings().timezone_exibicao)).date()


def _fila_saida(fila: Fila, unidade: Unidade, especialidade: Especialidade, motivo: str | None):
    return {
        "id": fila.id,
        "nome": fila.nome,
        "descricao_paciente": fila.descricao_paciente,
        "unidade": UnidadeSaida(id=unidade.id, sigla=unidade.sigla, nome=unidade.nome),
        "especialidade": EspecialidadeSaida(id=especialidade.id, nome=especialidade.nome),
        "elegivel": motivo is None,
        "motivo_inelegivel": motivo,
    }


def _filas_ativas():
    return (
        select(Fila, Unidade, Especialidade)
        .join(Unidade, Unidade.id == Fila.unidade_id)
        .join(Especialidade, Especialidade.id == Fila.especialidade_id)
        .where(Fila.ativa)
    )


def _resumo(s: Solicitacao, fila: Fila, unidade: Unidade) -> dict:
    return {
        "id": s.id,
        "status": s.status,
        "fila": FilaResumo(
            id=fila.id,
            nome=fila.nome,
            unidade=UnidadeSaida(id=unidade.id, sigla=unidade.sigla, nome=unidade.nome),
        ),
        "data_pedido": s.data_pedido,
        "criada_em": s.criada_em,
    }


def _detalhe(session: Session, paciente_id: UUID, solicitacao_id: UUID) -> SolicitacaoDetalhe:
    linha = session.execute(
        select(Solicitacao, Fila, Unidade)
        .join(Fila, Fila.id == Solicitacao.fila_id)
        .join(Unidade, Unidade.id == Fila.unidade_id)
        .where(Solicitacao.id == solicitacao_id, Solicitacao.paciente_id == paciente_id)
    ).one_or_none()
    if linha is None:
        raise HTTPException(404, "Solicitação não encontrada.")
    s, fila, unidade = linha
    fuso = ZoneInfo(get_settings().timezone_exibicao)
    respostas = session.execute(
        select(CriterioFila.descricao, RespostaCriterio.valor)
        .join(CriterioFila, CriterioFila.id == RespostaCriterio.criterio_id)
        .where(RespostaCriterio.solicitacao_id == s.id, CriterioFila.origem == "PACIENTE")
        .order_by(CriterioFila.codigo)
    )
    eventos = session.execute(
        select(
            HistoricoSolicitacao.tipo, HistoricoSolicitacao.ocorrido_em, HistoricoSolicitacao.motivo
        )
        .where(HistoricoSolicitacao.solicitacao_id == s.id, HistoricoSolicitacao.visivel_paciente)
        .order_by(HistoricoSolicitacao.ocorrido_em, HistoricoSolicitacao.seq)
    )
    ativo = session.execute(
        select(Agendamento, Vaga, Agenda.profissional)
        .join(Vaga, Vaga.id == Agendamento.vaga_id)
        .join(Agenda, Agenda.id == Vaga.agenda_id)
        .where(Agendamento.solicitacao_id == s.id, Agendamento.status.in_(ATIVOS))
    ).one_or_none()
    return SolicitacaoDetalhe(
        **_resumo(s, fila, unidade),
        turno_preferido=s.turno_preferido,
        origem_encaminhamento=s.origem_encaminhamento,
        respostas=[RespostaPaciente(descricao=d, valor=v) for d, v in respostas],
        linha_do_tempo=[
            EventoPaciente(tipo=t, data=o.astimezone(fuso).date(), motivo=m) for t, o, m in eventos
        ],
        agendamento_ativo=_agendamento_paciente(*ativo, unidade, fuso) if ativo else None,
    )


def _agendamento_resumo(
    a: Agendamento, vaga: Vaga, profissional: str, unidade: Unidade, fuso: ZoneInfo
) -> dict:
    return {
        "id": a.id,
        "status": a.status,
        "inicio": vaga.inicio.astimezone(fuso),
        "expira_em": a.expira_em.astimezone(fuso) if a.status == "PROPOSTO" else None,
        "unidade": UnidadeSaida(id=unidade.id, sigla=unidade.sigla, nome=unidade.nome),
        "profissional": profissional,
    }


def _agendamento_paciente(
    a: Agendamento, vaga: Vaga, profissional: str, unidade: Unidade, fuso: ZoneInfo
) -> AgendamentoPaciente:
    return AgendamentoPaciente(
        **_agendamento_resumo(a, vaga, profissional, unidade, fuso),
        fim=vaga.fim.astimezone(fuso),
        endereco=unidade.endereco,
    )


# --- filas --------------------------------------------------------------------------------


@router.get("/filas", responses=erros(*PACIENTE_LEITURA))
def listar_filas(
    paciente: PacienteDep,
    session: SessionDep,
    relogio: RelogioDep,
    limit: Limit = 50,
    offset: Offset = 0,
) -> PaginaFilas:
    """Filas ativas, com a elegibilidade do paciente (RN-017). `total` é o das filas ativas,
    nunca contagem de pessoas."""
    hoje = _hoje(relogio)
    linhas = session.execute(
        _filas_ativas().order_by(Unidade.sigla, Fila.nome, Fila.id).limit(limit).offset(offset)
    )
    total = session.scalar(select(func.count()).select_from(Fila).where(Fila.ativa))
    return PaginaFilas(
        total=total or 0,
        itens=[
            FilaSaida(**_fila_saida(f, u, e, motivo_de_inelegibilidade(paciente, f, hoje)))
            for f, u, e in linhas
        ],
    )


@router.get("/filas/{fila_id}", responses=erros(*PACIENTE_LEITURA, 404))
def detalhar_fila(
    fila_id: UUID, paciente: PacienteDep, session: SessionDep, relogio: RelogioDep
) -> FilaDetalheSaida:
    """Fila e as perguntas de origem PACIENTE do protocolo, sem peso nem pontos."""
    linha = session.execute(_filas_ativas().where(Fila.id == fila_id)).one_or_none()
    if linha is None:
        raise HTTPException(404, "Fila não encontrada.")
    fila, unidade, especialidade = linha
    criterios = session.scalars(
        select(CriterioFila)
        .where(
            CriterioFila.fila_id == fila.id, CriterioFila.ativo, CriterioFila.origem == "PACIENTE"
        )
        .order_by(CriterioFila.codigo)
    )
    return FilaDetalheSaida(
        **_fila_saida(
            fila, unidade, especialidade, motivo_de_inelegibilidade(paciente, fila, _hoje(relogio))
        ),
        criterios=[
            CriterioPacienteSaida(
                id=c.id,
                codigo=c.codigo,
                descricao=c.descricao,
                tipo=c.tipo,
                opcoes=sorted(c.parametros.get("opcoes", {})) if c.tipo == "OPCAO" else None,
            )
            for c in criterios
        ],
    )


# --- solicitações -------------------------------------------------------------------------


@router.post(
    "/solicitacoes",
    status_code=201,
    responses=erros(
        *PACIENTE_ESCRITA,
        (403, "sem-consentimento"),
        (409, "nao-elegivel", "solicitacao-duplicada"),
    ),
)
def criar(
    dados: SolicitacaoEntrada,
    request: Request,
    paciente: PacienteDep,
    session: SessionDep,
    relogio: RelogioDep,
) -> SolicitacaoDetalhe:
    """UC-002: cria a solicitação em EM_ANALISE, com a nota das respostas (RN-006)."""
    agora = relogio.agora()
    s = criar_solicitacao(
        session,
        paciente,
        dados.fila_id,
        [(r.criterio_id, r.valor) for r in dados.respostas],
        turno_preferido=dados.turno_preferido,
        origem_encaminhamento=dados.origem_encaminhamento,
        agora=agora,
        hoje=_hoje(relogio),
        ip=ip_do_cliente(request),
    )
    session.commit()
    logger.info("solicitacao criada: id=%s fila=%s", s.id, s.fila_id)
    return _detalhe(session, paciente.id, s.id)


@router.get("/solicitacoes", responses=erros(*PACIENTE_LEITURA))
def listar(
    paciente: PacienteDep,
    session: SessionDep,
    situacao: Literal["abertas", "encerradas"] | None = None,
    limit: Limit = 50,
    offset: Offset = 0,
) -> PaginaSolicitacoes:
    """Solicitações do paciente. `encerradas` alimenta o "Histórico de atendimentos".

    Uma consulta traz o agendamento ativo de cada item (sem N+1), mais a contagem do filtro.
    """
    filtro = [Solicitacao.paciente_id == paciente.id]
    if situacao == "abertas":
        filtro.append(Solicitacao.status.not_in(ENCERRADAS))
    elif situacao == "encerradas":
        filtro.append(Solicitacao.status.in_(ENCERRADAS))
    linhas = session.execute(
        select(Solicitacao, Fila, Unidade, Agendamento, Vaga, Agenda.profissional)
        .join(Fila, Fila.id == Solicitacao.fila_id)
        .join(Unidade, Unidade.id == Fila.unidade_id)
        .outerjoin(
            Agendamento,
            and_(Agendamento.solicitacao_id == Solicitacao.id, Agendamento.status.in_(ATIVOS)),
        )
        .outerjoin(Vaga, Vaga.id == Agendamento.vaga_id)
        .outerjoin(Agenda, Agenda.id == Vaga.agenda_id)
        .where(*filtro)
        .order_by(Solicitacao.criada_em.desc(), Solicitacao.id)
        .limit(limit)
        .offset(offset)
    )
    total = session.scalar(select(func.count()).select_from(Solicitacao).where(*filtro))
    fuso = ZoneInfo(get_settings().timezone_exibicao)
    return PaginaSolicitacoes(
        total=total or 0,
        itens=[
            SolicitacaoItem(
                **_resumo(s, f, u),
                agendamento_ativo=(
                    AgendamentoResumo(**_agendamento_resumo(a, v, profissional, u, fuso))
                    if a
                    else None
                ),
            )
            for s, f, u, a, v, profissional in linhas
        ],
    )


@router.get("/solicitacoes/{solicitacao_id}", responses=erros(*PACIENTE_LEITURA, 404))
def detalhar(
    solicitacao_id: UUID, paciente: PacienteDep, session: SessionDep
) -> SolicitacaoDetalhe:
    """Status, fila e linha do tempo só com os eventos visíveis ao paciente (RN-007)."""
    return _detalhe(session, paciente.id, solicitacao_id)


@router.post(
    "/solicitacoes/{solicitacao_id}/cancelar",
    responses=erros(*PACIENTE_ESCRITA, 404, (409, "transicao-invalida")),
)
def cancelar(
    solicitacao_id: UUID,
    request: Request,
    paciente: PacienteDep,
    session: SessionDep,
    relogio: RelogioDep,
    dados: CancelamentoEntrada,
) -> SolicitacaoDetalhe:
    """Cancelamento ("não vou precisar"): EM_ANALISE, NA_FILA, EM_PROPOSTA ou AGENDADA.

    Com proposta ou consulta ativa, o agendamento é cancelado junto, só antes do início da
    vaga; a vaga fica livre e o Worker a oferece ao próximo (RN-005). Outros estados → 409.
    Travas: solicitação, depois agendamento (a vaga só é lida).
    """
    s = session.scalar(
        select(Solicitacao)
        .where(Solicitacao.id == solicitacao_id, Solicitacao.paciente_id == paciente.id)
        .with_for_update()
        .execution_options(populate_existing=True)
    )
    if s is None:
        raise HTTPException(404, "Solicitação não encontrada.")
    agora = relogio.agora()
    ativo = session.execute(
        select(Agendamento, Vaga.inicio)
        .join(Vaga, Vaga.id == Agendamento.vaga_id)
        .where(Agendamento.solicitacao_id == s.id, Agendamento.status.in_(ATIVOS))
        .with_for_update(of=Agendamento)
        .execution_options(populate_existing=True)
    ).one_or_none()
    cancelar_do_paciente(
        session,
        s,
        ativo,
        dados.motivo_codigo,
        agora=agora,
        usuario_id=paciente.usuario_id,
        ip=ip_do_cliente(request),
    )
    session.commit()
    logger.info("solicitacao cancelada: id=%s", s.id)
    return _detalhe(session, paciente.id, s.id)


# --- resposta à proposta ------------------------------------------------------------------


def _travar_do_paciente(
    session: Session, agendamento_id: UUID, paciente: Paciente
) -> tuple[Solicitacao, Agendamento]:
    """Trava solicitação e agendamento do próprio paciente; de outro paciente, 404 (AM-001)."""
    par = travar_agendamento(session, agendamento_id, Solicitacao.paciente_id == paciente.id)
    if par is None:
        raise HTTPException(404, "Agendamento não encontrado.")
    return par


@router.post(
    "/agendamentos/{agendamento_id}/confirmar",
    responses=erros(*PACIENTE_ESCRITA, 404, (409, "transicao-invalida", "proposta-expirada")),
)
def confirmar(
    agendamento_id: UUID,
    request: Request,
    paciente: PacienteDep,
    session: SessionDep,
    relogio: RelogioDep,
) -> SolicitacaoDetalhe:
    """UC-004: PROPOSTO → CONFIRMADO e solicitação AGENDADA, só antes de `expira_em`."""
    s, a = _travar_do_paciente(session, agendamento_id, paciente)
    agora = relogio.agora()
    confirmar_do_paciente(
        session, s, a, agora=agora, usuario_id=paciente.usuario_id, ip=ip_do_cliente(request)
    )
    session.commit()
    logger.info("agendamento confirmado: id=%s", a.id)
    return _detalhe(session, paciente.id, s.id)


@router.post(
    "/agendamentos/{agendamento_id}/recusar",
    responses=erros(*PACIENTE_ESCRITA, 404, (409, "transicao-invalida", "proposta-expirada")),
)
def recusar(
    agendamento_id: UUID,
    request: Request,
    paciente: PacienteDep,
    session: SessionDep,
    relogio: RelogioDep,
) -> SolicitacaoDetalhe:
    """UC-005 ("esta data não serve"): só PROPOSTO. A vaga fica livre para o próximo."""
    s, a = _travar_do_paciente(session, agendamento_id, paciente)
    agora = relogio.agora()
    recusar_do_paciente(
        session, s, a, agora=agora, usuario_id=paciente.usuario_id, ip=ip_do_cliente(request)
    )
    session.commit()
    logger.info("proposta recusada: id=%s", a.id)
    return _detalhe(session, paciente.id, s.id)
