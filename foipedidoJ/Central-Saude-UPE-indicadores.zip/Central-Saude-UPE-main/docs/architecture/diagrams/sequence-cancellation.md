# Sequência — pedir outra data e liberar a vaga

Cenário de [UC-005](../../requirements/use-cases/UC-005-pedir-outra-data-ou-cancelar.md). O trecho final mostra a variante automática, que é a do MVP ([ADR-021](../../decisions/ADR-021-matching-automatico.md)).

```mermaid
sequenceDiagram
  autonumber
  actor P as Paciente
  participant A as API
  participant D as PostgreSQL
  participant W as Worker
  actor P2 as Próximo paciente

  P->>A: POST /agendamentos/{id}/recusar
  A->>D: BEGIN · SELECT ... FOR UPDATE
  A->>D: UPDATE agendamento → CANCELADO (RECUSADO_PELO_PACIENTE)
  A->>D: UPDATE solicitação → NA_FILA
  A->>D: INSERT auditoria
  A->>D: INSERT outbox (PROPOSTA_RECUSADA)
  A->>D: COMMIT
  A-->>P: 200 · "você continua na fila"
  Note over D: a vaga fica livre sem atualizar a tabela vaga<br/>(nenhum agendamento ativo aponta para ela)

  W->>D: SELECT outbox PENDENTE FOR UPDATE SKIP LOCKED
  W->>D: avisa P do cancelamento
  W->>D: busca a primeira solicitação da fila da vaga (ordenar_fila)
  W->>D: INSERT agendamento PROPOSTO para P2 + outbox
  alt outra transação ocupou a vaga antes
    D-->>W: violação do índice único
    W->>W: descarta a tentativa
  end
  W->>P2: aviso de nova vaga (site e e-mail)
```

A variante automática é a do MVP (ADR-021). Na variante manual, de fase futura, os passos de matching saem do Worker: a vaga aparece como livre na fila do atendente, que faz a proposta pela API ([UC-003](../../requirements/use-cases/UC-003-propor-vaga.md)).
